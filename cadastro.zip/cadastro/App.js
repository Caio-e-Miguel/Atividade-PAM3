import React, { useState } from 'react';
import { SafeAreaView, StyleSheet, View } from 'react-native';
import { TextInput, Button, Text, Card, Provider as PaperProvider, DefaultTheme, configureFonts } from 'react-native-paper';

// Tema escuro personalizado
const darkTheme = {
  ...DefaultTheme,
  dark: true,
  colors: {
    ...DefaultTheme.colors,
    primary: '#BB86FC',
    background: '#121212',
    surface: '#1E1E1E',
    text: '#FFFFFF',
    placeholder: '#888',
  },
};

export default function App() {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [erros, setErros] = useState({});

  const handleCadastro = () => {
    const novosErros = {};

    if (!nome.trim()) novosErros.nome = 'Digite seu nome.';
    if (!email.trim()) novosErros.email = 'Digite seu e-mail.';
    if (!senha.trim()) novosErros.senha = 'Digite sua senha.';

    setErros(novosErros);

    if (Object.keys(novosErros).length === 0) {
      setMensagem(`Usuário ${nome} cadastrado com sucesso!`);
      console.log({ nome, email, senha });
      setNome('');
      setEmail('');
      setSenha('');
    } else {
      setMensagem('');
    }
  };

  return (
    <PaperProvider theme={darkTheme}>
      <SafeAreaView style={styles.container}>
        <Card style={styles.card}>
          <Card.Title title="Cadastro de Usuário" titleStyle={{ color: '#FFF' }} />
          <Card.Content>
            <TextInput
              label="Nome"
              value={nome}
              onChangeText={setNome}
              style={styles.input}
              mode="outlined"
              error={!!erros.nome}
            />
            {erros.nome && <Text style={styles.erro}>{erros.nome}</Text>}

            <TextInput
              label="E-mail"
              value={email}
              onChangeText={setEmail}
              style={styles.input}
              mode="outlined"
              keyboardType="email-address"
              error={!!erros.email}
            />
            {erros.email && <Text style={styles.erro}>{erros.email}</Text>}

            <TextInput
              label="Senha"
              value={senha}
              onChangeText={setSenha}
              style={styles.input}
              mode="outlined"
              secureTextEntry
              error={!!erros.senha}
            />
            {erros.senha && <Text style={styles.erro}>{erros.senha}</Text>}

            <Button mode="contained" onPress={handleCadastro} style={styles.button}>
              Cadastrar
            </Button>

            {mensagem !== '' && <Text style={styles.sucesso}>{mensagem}</Text>}
          </Card.Content>
        </Card>
      </SafeAreaView>
    </PaperProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
    justifyContent: 'center',
    padding: 16,
  },
  card: {
    padding: 16,
    backgroundColor: '#1E1E1E',
  },
  input: {
    marginBottom: 8,
    backgroundColor: '#2A2A2A',
  },
  button: {
    marginTop: 12,
    backgroundColor: '#007FFF',
  },
  sucesso: {
    marginTop: 16,
    textAlign: 'center',
    fontSize: 16,
    color: '#03DAC6',
  },
  erro: {
    color: '#CF6679',
    marginBottom: 8,
    fontSize: 14,
  },
});
